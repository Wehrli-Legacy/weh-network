# Portal

User-facing WEH portal.

Main features:

- user registration and login;
- wallet dashboard;
- WEH purchase flow;
- Mining Dividends claim button;
- balance display.
