<?php
// Production version reads from transactions table.
header('Content-Type: application/json; charset=utf-8');

echo json_encode([
    'success' => true,
    'data' => []
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
