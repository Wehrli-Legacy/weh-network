<?php
header('Content-Type: application/json; charset=utf-8');

echo json_encode([
    'success' => true,
    'symbol' => 'WEH',
    'price_usd' => null,
    'source' => 'treasury_or_market_defined',
    'timestamp' => time()
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
