<?php
header('Content-Type: application/json; charset=utf-8');

echo json_encode([
    'success' => true,
    'symbol' => 'WEH',
    'total_supply' => 100000000,
    'decimals' => 7,
    'network' => 'WEH Network',
    'type' => 'native_centralized_coin'
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
