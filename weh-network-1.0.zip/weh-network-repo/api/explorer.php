<?php
// Production version requires authentication token and reads explorer data from the database.
header('Content-Type: application/json; charset=utf-8');

echo json_encode([
    'success' => true,
    'message' => 'WEH Explorer API template'
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
