# API

This folder contains public API endpoint templates for WEH Network integrations.

Production secrets and database credentials must not be committed here.
