# Admin

Administrative system for WEH Network.

Main modules:

- Company Wallet;
- Mining Dividends monitoring;
- Founder Wallets;
- withdrawals;
- price/API management.
