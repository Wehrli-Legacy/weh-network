# WEH Tokenomics

## Total Supply

**100,000,000 WEH**

## Allocation

| Category | Allocation |
|---|---:|
| Founders | 3,000,000 WEH |
| Opening Round and Initial Capital Raise | 500,000 WEH |
| Meta Market Round | 500,000 WEH |
| Asset Acquisition | 1,000,000 WEH |
| Global Expansion | 5,000,000 WEH |
| Mining Dividends Reserve | 90,000,000 WEH |
| **Total** | **100,000,000 WEH** |

## Circulation Logic

WEH is released through treasury-controlled distribution, market rounds, founder allocation, and Mining Dividends.

## Supply Policy

- Fixed total supply
- No post-genesis minting
- Controlled treasury distribution
- Mining Dividends paid from the reserved supply through Company Wallet logic
