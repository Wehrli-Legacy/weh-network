# WEH Exchange Listing Information

## Project Information

```text
Project Name: Wehrli Legacy
Asset Name: WEH
Symbol: WEH
Type: Native Coin (Centralized)
Total Supply: 100,000,000 WEH
Decimals: 7
Network: Proprietary centralized ledger
Consensus: Controlled by Wehrli Legacy
Mining Model: Mining Dividends
```

## Explorer

```text
https://explorer.wehrlilegacy.org
```

## API Base

```text
https://weh.wehrlilegacy.org/api/
```

## Wallet Model

```text
Wallet Type: Custodial API-based system
Address Format: WEH + hash
Transaction Hash: SHA256-based unique identifier
```

## Deposit and Withdrawal

```text
Deposits: API-based / centralized validation
Withdrawals: manual approval in the initial stage
```

## Tokenomics

```text
Total Supply: 100,000,000 WEH
Founders: 3,000,000 WEH
Market and Expansion: 7,000,000 WEH
Mining Dividends Reserve: 90,000,000 WEH
```

## Disclosure

WEH is a centralized native coin. It is operated and controlled by Wehrli Legacy through a proprietary ledger and treasury system.
