# WEH Genesis Package

## Fundamental Network Rules

WEH is a native centralized digital coin operated by Wehrli Legacy.

## Network Nature

- Type: Native centralized coin
- Ledger: Proprietary centralized ledger
- Consensus: Controlled by Wehrli Legacy
- Reward Model: Mining Dividends
- Treasury: Company Wallet

## Asset Identity

- Asset Name: WEH
- Symbol: WEH
- Decimals: 7
- Total Supply: 100,000,000 WEH
- Minimum Network Fee: 0.0000100 WEH

## Genesis Supply

The full supply is created at genesis.

- Genesis supply: 100,000,000 WEH
- Post-genesis minting: disabled
- Future supply expansion: none

## Company Wallet

The Company Wallet is the treasury source for:

- market sale allocations;
- founder allocations;
- Mining Dividends rewards;
- administrative redistribution;
- fee collection;
- treasury operations.

## Mining Dividends

Mining Dividends is a centralized reward system based on locked balances and elapsed locked time.

At initial difficulty:

```text
100 locked WEH + 10 eligible minutes = 1 mined WEH
```

Each successful claim creates an internal mining block.
