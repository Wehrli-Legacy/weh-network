# Mining Dividends

Mining Dividends is the WEH Network reward model.

It is not proof-of-work mining. It is a centralized, treasury-backed reward mechanism based on:

- locked WEH balance;
- elapsed locked time;
- current network difficulty;
- global mined total.

## Base Rule

At initial difficulty:

```text
100 WEH locked for 10 eligible minutes = 1 WEH mined
```

## Eligibility

A wallet must have at least 100 locked WEH.

Only full lots of 100 WEH are counted.

## Claim Model

Mining is triggered when a user clicks **Mining Dividends**.

A successful claim:

1. calculates the reward;
2. debits the Company Wallet;
3. credits the reward as locked balance;
4. records a mining block;
5. updates the wallet mining state.

## Difficulty Model

```text
difficulty_level = floor(global_mined_total / 1000)
required_minutes = 10 + difficulty_level
reward_per_100_locked = 1 / (2 ^ difficulty_level)
```

Every 1,000 WEH mined globally:

- required time increases by 1 minute;
- reward per 100 locked WEH is halved.
