# WEH API Reference

## Base URL

```text
https://weh.wehrlilegacy.org/api/
```

## Supply

```text
GET /api/supply.php
```

Returns total supply, circulating supply, locked supply, and treasury-related supply data when available.

## Price

```text
GET /api/price.php
```

Returns the current WEH price information.

## Blocks

```text
GET /api/blocks.php
```

Returns recent Mining Dividends blocks.

## Transactions

```text
GET /api/transactions.php
```

Returns recent network transactions.

## Explorer API

```text
GET /api/explorer.php?token=TOKEN&mode=overview
```

Supported modes may include:

- overview;
- blocks;
- block;
- transactions;
- tx;
- wallets;
- wallet;
- orders;
- contracts.
