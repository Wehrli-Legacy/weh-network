CREATE TABLE IF NOT EXISTS wallet_mining_state (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    wallet_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NULL,
    mining_started_at DATETIME NOT NULL,
    last_claimed_at DATETIME NULL,
    total_mined DECIMAL(36,18) NOT NULL DEFAULT 0,
    total_blocks BIGINT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_wallet_mining_state_wallet (wallet_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS mining_blocks (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    block_height BIGINT UNSIGNED NOT NULL,
    prev_block_hash VARCHAR(128) NULL,
    block_hash VARCHAR(128) NOT NULL,
    wallet_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NULL,
    wallet_code VARCHAR(120) NULL,
    difficulty_value INT NOT NULL DEFAULT 10,
    required_minutes INT NOT NULL DEFAULT 10,
    reward_per_100_locked DECIMAL(36,18) NOT NULL DEFAULT 0,
    locked_balance_snapshot DECIMAL(36,18) NOT NULL DEFAULT 0,
    eligible_lots BIGINT UNSIGNED NOT NULL DEFAULT 0,
    elapsed_minutes BIGINT UNSIGNED NOT NULL DEFAULT 0,
    mine_cycles BIGINT UNSIGNED NOT NULL DEFAULT 0,
    gross_reward DECIMAL(36,18) NOT NULL DEFAULT 0,
    network_fee DECIMAL(36,18) NOT NULL DEFAULT 0,
    net_reward DECIMAL(36,18) NOT NULL DEFAULT 0,
    company_wallet_id BIGINT UNSIGNED NOT NULL,
    source_wallet_code VARCHAR(120) NOT NULL DEFAULT 'COMPANY_ADMIN',
    status VARCHAR(30) NOT NULL DEFAULT 'confirmed',
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_mining_blocks_height (block_height),
    UNIQUE KEY uq_mining_blocks_hash (block_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
