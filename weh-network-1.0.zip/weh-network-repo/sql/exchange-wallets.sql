CREATE TABLE IF NOT EXISTS wallet_addresses (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    wallet_id BIGINT NOT NULL,
    address VARCHAR(120) NOT NULL UNIQUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS deposits (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT,
    wallet_id BIGINT,
    address VARCHAR(120),
    amount DECIMAL(36,18),
    asset VARCHAR(20) DEFAULT 'WEH',
    status VARCHAR(30) DEFAULT 'pending',
    txid VARCHAR(120),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    confirmed_at DATETIME NULL
);

CREATE TABLE IF NOT EXISTS withdrawals (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT,
    wallet_id BIGINT,
    address VARCHAR(120),
    amount DECIMAL(36,18),
    asset VARCHAR(20) DEFAULT 'WEH',
    status VARCHAR(30) DEFAULT 'pending',
    txid VARCHAR(120),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    processed_at DATETIME NULL
);
