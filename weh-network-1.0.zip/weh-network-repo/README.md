# WEH Network

WEH is a native centralized digital coin operated by Wehrli Legacy.

The WEH Network uses a proprietary ledger model with internal block generation, API-driven explorer data, wallet-based accounting, and a time-locked reward system called **Mining Dividends**.

## Core Facts

| Item | Value |
|---|---|
| Project | Wehrli Legacy |
| Asset | WEH |
| Type | Native centralized coin |
| Total Supply | 100,000,000 WEH |
| Decimals | 7 |
| Network Model | Proprietary centralized ledger |
| Consensus | Controlled by Wehrli Legacy |
| Reward Model | Mining Dividends |
| Explorer | https://explorer.wehrlilegacy.org |
| API Base | https://weh.wehrlilegacy.org/api/ |

## Key Features

- Native centralized coin infrastructure
- Fixed supply of 100,000,000 WEH
- Company Wallet treasury model
- Time-locked Mining Dividends reward system
- Internal mining blocks with block height and hash
- API-based wallet and explorer integration
- Public explorer for blocks, transactions, wallets, and supply visibility
- Exchange-ready technical documentation

## Public API Endpoints

- Supply: `https://weh.wehrlilegacy.org/api/supply.php`
- Price: `https://weh.wehrlilegacy.org/api/price.php`
- Blocks: `https://weh.wehrlilegacy.org/api/blocks.php`
- Transactions: `https://weh.wehrlilegacy.org/api/transactions.php`
- Explorer API: `https://weh.wehrlilegacy.org/api/explorer.php`

## Documentation

- [Genesis Package](docs/genesis-package.md)
- [Tokenomics](docs/tokenomics.md)
- [Mining Dividends](docs/mining-dividends.md)
- [API Reference](docs/api-reference.md)
- [Exchange Listing Info](docs/exchange-listing-info.md)
- [Technical Overview](docs/technical-overview.md)

## Important Disclosure

WEH is a centralized native coin operated by Wehrli Legacy. The network is not presented as a decentralized proof-of-work blockchain. It uses a proprietary ledger with internal block recording and treasury-controlled distribution.

## Security Notice

This repository must not include production secrets, database credentials, API tokens, private keys, wallet keys, or server passwords. Use `.env.example` as a safe template only.
