# Includes

Shared PHP logic for WEH Network.

Production files should load secrets from private server configuration, not from public repository files.
