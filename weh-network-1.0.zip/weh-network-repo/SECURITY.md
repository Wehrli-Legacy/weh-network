# Security Policy

Do not publish production secrets in this repository.

Never commit:

- database credentials;
- private keys;
- API tokens;
- wallet seed phrases;
- server passwords;
- production configuration files.

Use `.env.example` as a public template only.

For security matters, contact Wehrli Legacy through official channels.
